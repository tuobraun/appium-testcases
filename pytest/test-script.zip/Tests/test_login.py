import pytest

def test_login(mainfixture):
    mainfixture.login.enter_credentials("web_site_url", "user_name", "password")
    mainfixture.login.save_psswrd()
    mainfixture.login.click_login()
